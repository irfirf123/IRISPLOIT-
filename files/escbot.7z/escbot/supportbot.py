import telebot
from telebot import types
TOKEN = "7834667719:AAFMd85fhohOR_xzjdsxDUjpFEOix4D2w84"
ADMIN_ID = 1435646471
bot = telebot.TeleBot(TOKEN)
user_data = {}

# Создаем кастомную клавиатуру для администратора
def create_admin_keyboard():
    keyboard = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    btn_send_message = types.KeyboardButton("Отправить сообщение \U00002709")
    btn_send_photo = types.KeyboardButton("Отправить изображение \U0001F4F8")
    keyboard.add(btn_send_message, btn_send_photo)
    return keyboard

@bot.message_handler(commands=['start'])
def handle_start(message):
    if message.from_user.id == ADMIN_ID:
        # Админ получает кастомную клавиатуру
        bot.send_message(
            message.chat.id,
            "Вы вошли как администратор. Выберите действие:",
            reply_markup=create_admin_keyboard()
        )
    else:
        # Обычный пользователь получает приветственное сообщение
        welcome_text = (
            "Добро пожаловать в поддержку агентства Princess Girls! \U0001F451\n\n"
            "Для оперативного решения вашего вопроса, пожалуйста, укажите следующую информацию:\n"
            "1. Подробно опишите вашу проблему или вопрос.\n"
            "2. Предоставьте ваши контактные данные (номер телефона, email или Telegram username).\n"
            "3. Если вопрос связан с оплатой, приложите скриншот или фото подтверждения оплаты.\n\n"
            "Мы постараемся ответить вам в ближайшее время. Спасибо за ваше обращение! \U0001F48C"
        )
        bot.send_message(message.chat.id, welcome_text)

# Обработчик для всех входящих сообщений от пользователей
@bot.message_handler(func=lambda m: m.from_user.id != ADMIN_ID, content_types=['text', 'photo'])
def handle_user_message(message):
    try:
        # Формируем информацию о пользователе
        user_info = (
            f"\U0001F464 Имя: {message.from_user.first_name}\n"
            f"\U0001F194 ID: {message.from_user.id}\n"
            f"\U00002709 Юзернейм: @{message.from_user.username}"
        )

        if message.content_type == 'text':
            # Если пришло только текстовое сообщение
            bot.send_message(
                ADMIN_ID,
                f"Сообщение от пользователя:\n{message.text}\n\n{user_info}"
            )
        elif message.content_type == 'photo':
            # Если пришло фото
            file_id = message.photo[-1].file_id
            caption = message.caption
            bot.send_photo(
                ADMIN_ID,
                file_id,
                caption=f"Фото от пользователя:\n\n{caption}\n\n{user_info}"
            )
    except Exception as e:
        print(f"Ошибка: {e}")

# Обработчик для команд администратора
@bot.message_handler(func=lambda m: m.from_user.id == ADMIN_ID)
def handle_admin_commands(message):
    if message.text == "Отправить сообщение \U00002709":
        # Запрашиваем ID пользователя
        msg = bot.send_message(ADMIN_ID, "Введите ID пользователя:")
        bot.register_next_step_handler(msg, ask_user_message)
    elif message.text == "Отправить изображение \U0001F4F8":
        # Запрашиваем ID пользователя
        msg = bot.send_message(ADMIN_ID, "Введите ID пользователя:")
        bot.register_next_step_handler(msg, ask_user_photo)

def ask_user_message(message):
    try:
        user_id = int(message.text)  # Пытаемся преобразовать в число
        user_data[ADMIN_ID] = {"user_id": user_id, "action": "send_message"}
        msg = bot.send_message(ADMIN_ID, "Введите сообщение для отправки:")
        bot.register_next_step_handler(msg, send_user_message)
    except ValueError:
        bot.send_message(ADMIN_ID, "Некорректный ID. Пожалуйста, введите число.")

def ask_user_photo(message):
    try:
        user_id = int(message.text)  # Пытаемся преобразовать в число
        user_data[ADMIN_ID] = {"user_id": user_id, "action": "send_photo"}
        msg = bot.send_message(ADMIN_ID, "Отправьте изображение:")
        bot.register_next_step_handler(msg, send_user_photo)
    except ValueError:
        bot.send_message(ADMIN_ID, "Некорректный ID. Пожалуйста, введите число.")

def send_user_message(message):
    try:
        user_id = user_data[ADMIN_ID]["user_id"]
        text = message.text
        bot.send_message(user_id, text)
        bot.send_message(ADMIN_ID, f"Сообщение отправлено пользователю с ID {user_id}.")
    except Exception as e:
        bot.send_message(ADMIN_ID, f"Ошибка: {e}")

def send_user_photo(message):
    try:
        user_id = user_data[ADMIN_ID]["user_id"]
        if message.photo:
            # Берем последнее (самое большое) фото из списка
            file_id = message.photo[-1].file_id
            bot.send_photo(user_id, file_id)
            bot.send_message(ADMIN_ID, f"Изображение отправлено пользователю с ID {user_id}.")
        else:
            bot.send_message(ADMIN_ID, "Вы не отправили изображение.")
    except Exception as e:
        bot.send_message(ADMIN_ID, f"Ошибка: {e}")

if __name__ == "__main__":
    print("Бот запущен!")
    bot.polling(none_stop=True)