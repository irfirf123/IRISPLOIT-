 if IRISPLOIT then
	script:Remove()
	return 
end
getgenv()["IRISPLOIT"] = true
loadstring(game:HttpGet("https://raw.githubusercontent.com/ItzzExcel/LInjector/master/Redistributables/Lua%20Scripts/Init.lua"))() 